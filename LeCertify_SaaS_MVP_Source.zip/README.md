# LeCertify SaaS MVP

LeCertify is a SaaS-style ACME/Let's Encrypt certificate management web application built from scratch.

It is designed around the patterns in centralized certificate management projects such as Cert Warden, CertMate and Certify The Web, but implemented as a clean Next.js/TypeScript application.

## What this MVP includes

- Next.js SaaS web UI
- Neon/Supabase PostgreSQL via Prisma
- Microsoft Entra ID SSO scaffold using NextAuth
- Certificate inventory
- Issue certificate workflow
- ACME DNS-01 using `acme-client`
- Azure DNS TXT record automation
- Azure DNS `_acme-challenge` CNAME delegation support
- Encrypted certificate/private-key storage helper
- Audit log model
- Vercel-ready configuration
- Docker Compose local PostgreSQL dev stack

## Recommended free database

Use **Neon PostgreSQL Free Tier** or **Supabase PostgreSQL Free Tier**. For Vercel SaaS hosting, avoid SQLite because serverless filesystems are ephemeral and not suitable for certificate/private key state.

## Quick start locally

```bash
npm install
cp .env.example .env
npm run db:generate
npm run db:push
npm run dev
```

Open:

```text
http://localhost:3000
```

## Deploy to Vercel

1. Create a private GitHub repo named `lecertify`.
2. Push this code.
3. Import the GitHub repo in Vercel.
4. Add the environment variables from `.env.example`.
5. Use Neon or Supabase PostgreSQL for `DATABASE_URL`.
6. Deploy.

## Upload to your GitHub private repo

```bash
git init
git add .
git commit -m "Initial LeCertify SaaS MVP"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/lecertify.git
git push -u origin main
```

## DNS model for lecertify.breeding.kiwi

Primary application DNS:

```text
lecertify.breeding.kiwi A <your-hosting-ip-or-cname-target>
```

ACME DNS-01 CNAME delegation:

```text
_acme-challenge.lecertify.breeding.kiwi CNAME lecertify-breeding-kiwi.acme-validation.breeding.kiwi
```

The application then writes ACME TXT records into the validation zone:

```text
lecertify-breeding-kiwi.acme-validation.breeding.kiwi TXT <acme-value>
```

## Important production notes

- Start with the Let's Encrypt staging directory.
- Switch to production only after DNS validation succeeds.
- Store Azure credentials only in hosting environment variables.
- Use an Entra ID service principal scoped as DNS Zone Contributor only on the validation zone where possible.
- Use Azure Key Vault for certificate storage in a future hardening phase if preferred.
- Background certificate renewal is included as a Vercel cron endpoint scaffold, but a durable worker such as Azure Container Apps is recommended for long-running production issuance.

## Key files

```text
src/lib/acme.ts          ACME issuance flow
src/lib/azure-dns.ts     Azure DNS TXT/CNAME automation
src/lib/auth.ts          Entra ID / NextAuth configuration
src/lib/crypto.ts        Encryption helper for cert/key content
prisma/schema.prisma     Database schema
src/app/page.tsx         Dashboard
src/app/certificates     Certificate screens
```
