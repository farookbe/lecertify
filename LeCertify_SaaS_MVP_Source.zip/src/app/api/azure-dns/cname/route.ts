import { NextRequest, NextResponse } from 'next/server';
import { upsertChallengeCname } from '@/lib/azure-dns';

export async function POST(req: NextRequest) {
  const body = await req.json();
  const result = await upsertChallengeCname(String(body.domain));
  return NextResponse.json(result);
}
