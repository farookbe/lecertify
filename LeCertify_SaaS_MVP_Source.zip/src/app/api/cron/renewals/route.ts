import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function GET() {
  const due = await prisma.certificate.findMany({
    where: { status: 'ISSUED', notAfter: { lte: new Date(Date.now() + 30 * 86400000) } },
    take: 25
  });
  // Production phase: enqueue durable jobs for Azure Container Apps, Inngest, Trigger.dev, or a worker.
  return NextResponse.json({ dueCount: due.length, message: 'Renewal scan complete. Durable worker enqueue is scaffolded for phase 2.' });
}
