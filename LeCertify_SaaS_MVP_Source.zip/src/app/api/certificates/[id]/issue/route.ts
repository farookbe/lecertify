import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { issueCertificate } from '@/lib/acme';
import { audit } from '@/lib/audit';

export async function POST(_req: NextRequest, { params }: { params: { id: string } }) {
  const cert = await prisma.certificate.findUnique({ where: { id: params.id } });
  if (!cert) return NextResponse.json({ error: 'Certificate not found' }, { status: 404 });

  const job = await prisma.certificateJob.create({ data: { certificateId: cert.id, type: 'issue', status: 'PENDING', output: 'Starting ACME DNS-01 issuance' } });
  await prisma.certificate.update({ where: { id: cert.id }, data: { status: 'PENDING' } });

  try {
    const result = await issueCertificate({
      commonName: cert.commonName,
      subjectAltNames: cert.subjectAltNames,
      caDirectoryUrl: cert.caDirectoryUrl,
      useCnameDelegation: cert.useCnameDelegation
    });
    await prisma.certificate.update({
      where: { id: cert.id },
      data: {
        status: 'ISSUED',
        encryptedCertPem: result.encryptedCertPem,
        encryptedPrivateKey: result.encryptedPrivateKey,
        lastError: null
      }
    });
    await prisma.certificateJob.update({ where: { id: job.id }, data: { status: 'ISSUED', completedAt: new Date(), output: 'Certificate issued and encrypted in database.' } });
    await audit('certificate.issued', cert.id, { commonName: cert.commonName });
    return NextResponse.json({ ok: true, jobId: job.id });
  } catch (err: any) {
    await prisma.certificate.update({ where: { id: cert.id }, data: { status: 'FAILED', lastError: err.message } });
    await prisma.certificateJob.update({ where: { id: job.id }, data: { status: 'FAILED', completedAt: new Date(), output: err.stack ?? err.message } });
    await audit('certificate.issue_failed', cert.id, { error: err.message });
    return NextResponse.json({ ok: false, error: err.message }, { status: 500 });
  }
}
