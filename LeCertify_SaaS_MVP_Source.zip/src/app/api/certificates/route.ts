import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { audit } from '@/lib/audit';

export async function GET() {
  const certs = await prisma.certificate.findMany({ orderBy: { updatedAt: 'desc' } });
  return NextResponse.json(certs);
}

export async function POST(req: NextRequest) {
  const contentType = req.headers.get('content-type') ?? '';
  let body: any;
  if (contentType.includes('application/json')) body = await req.json();
  else {
    const form = await req.formData();
    body = Object.fromEntries(form.entries());
  }

  const commonName = String(body.commonName);
  const subjectAltNames = String(body.sans ?? commonName).split(',').map(x => x.trim()).filter(Boolean);
  const cert = await prisma.certificate.create({
    data: {
      commonName,
      subjectAltNames,
      friendlyName: body.friendlyName ? String(body.friendlyName) : commonName,
      caDirectoryUrl: String(body.caDirectoryUrl ?? process.env.ACME_DIRECTORY_URL),
      useCnameDelegation: true,
      challengeRecord: `_acme-challenge.${commonName.replace(/^\*\./, '')}`,
      cnameTarget: String(body.cnameTarget ?? '') || null
    }
  });
  await audit('certificate.created', cert.id, { commonName });
  if (contentType.includes('application/json')) return NextResponse.json(cert, { status: 201 });
  return NextResponse.redirect(new URL(`/certificates/${cert.id}`, req.url));
}
