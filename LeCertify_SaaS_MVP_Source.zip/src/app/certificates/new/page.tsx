export default function NewCertificatePage() {
  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <h1 className="text-3xl font-bold">New certificate</h1>
      <form action="/api/certificates" method="post" className="card space-y-4 p-6">
        <div><label className="label">Common name</label><input name="commonName" className="input" defaultValue="lecertify.breeding.kiwi" /></div>
        <div><label className="label">SANs, comma separated</label><input name="sans" className="input" defaultValue="lecertify.breeding.kiwi" /></div>
        <div><label className="label">CNAME target</label><input name="cnameTarget" className="input" defaultValue="lecertify-breeding-kiwi.acme-validation.breeding.kiwi" /></div>
        <div><label className="label">CA directory URL</label><input name="caDirectoryUrl" className="input" defaultValue="https://acme-staging-v02.api.letsencrypt.org/directory" /></div>
        <button className="btn" type="submit">Create draft</button>
      </form>
    </div>
  );
}
