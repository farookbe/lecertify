import { prisma } from '@/lib/db';
import { notFound } from 'next/navigation';

export default async function CertificateDetail({ params }: { params: { id: string } }) {
  const cert = await prisma.certificate.findUnique({ where: { id: params.id }, include: { jobs: { orderBy: { createdAt: 'desc' } } } });
  if (!cert) notFound();
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div><h1 className="text-3xl font-bold">{cert.commonName}</h1><p className="text-slate-600">{cert.status} · {cert.caDirectoryUrl}</p></div>
        <form action={`/api/certificates/${cert.id}/issue`} method="post"><button className="btn">Issue / Renew now</button></form>
      </div>
      <section className="card p-5">
        <h2 className="text-xl font-semibold">DNS-01 challenge</h2>
        <div className="mt-3 rounded-xl bg-slate-50 p-4 text-sm">
          <div><b>Challenge record:</b> {cert.challengeRecord ?? `_acme-challenge.${cert.commonName}`}</div>
          <div><b>CNAME target:</b> {cert.cnameTarget ?? 'not configured'}</div>
        </div>
      </section>
      <section className="card p-5">
        <h2 className="text-xl font-semibold">Jobs</h2>
        <div className="mt-3 space-y-3">{cert.jobs.map(j => <pre key={j.id} className="rounded-xl bg-slate-900 p-3 text-xs text-slate-100">{j.type} · {j.status}\n{j.output}</pre>)}</div>
      </section>
    </div>
  );
}
