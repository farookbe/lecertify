import { prisma } from '@/lib/db';

export default async function CertificatesPage() {
  const certs = await prisma.certificate.findMany({ orderBy: { updatedAt: 'desc' } });
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Certificates</h1>
          <p className="text-slate-600">Create, issue, renew and track all certificates.</p>
        </div>
        <a href="/certificates/new" className="btn">New certificate</a>
      </div>
      <div className="card overflow-hidden">
        <table className="w-full text-left text-sm">
          <thead className="bg-slate-50 text-slate-600"><tr><th className="p-3">Name</th><th>Status</th><th>Expires</th><th>DNS</th><th></th></tr></thead>
          <tbody>
            {certs.map(c => <tr key={c.id} className="border-t"><td className="p-3 font-medium">{c.commonName}</td><td>{c.status}</td><td>{c.notAfter?.toISOString().slice(0,10) ?? 'Pending'}</td><td>{c.cnameTarget ?? '-'}</td><td><a className="btn-secondary" href={`/certificates/${c.id}`}>Manage</a></td></tr>)}
          </tbody>
        </table>
      </div>
    </div>
  );
}
