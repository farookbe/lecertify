export default function SettingsPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Settings</h1>
      <div className="card p-6">
        <h2 className="text-xl font-semibold">Environment configuration</h2>
        <p className="mt-2 text-slate-600">Configure Entra ID, Azure DNS, ACME and database settings using environment variables in Vercel/Netlify or your Docker host.</p>
        <pre className="mt-4 rounded-xl bg-slate-900 p-4 text-sm text-slate-100">AZURE_PRIMARY_DNS_ZONE=breeding.kiwi{`\n`}AZURE_VALIDATION_DNS_ZONE=acme-validation.breeding.kiwi{`\n`}ACME_DIRECTORY_URL=https://acme-staging-v02.api.letsencrypt.org/directory</pre>
      </div>
    </div>
  );
}
