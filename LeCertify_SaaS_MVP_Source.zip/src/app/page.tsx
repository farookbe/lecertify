import { prisma } from '@/lib/db';

export default async function Dashboard() {
  const [total, issued, failed, expiring] = await Promise.all([
    prisma.certificate.count(),
    prisma.certificate.count({ where: { status: 'ISSUED' } }),
    prisma.certificate.count({ where: { status: 'FAILED' } }),
    prisma.certificate.count({ where: { notAfter: { lte: new Date(Date.now() + 30 * 86400000) } } })
  ]);

  const recent = await prisma.certificate.findMany({ orderBy: { updatedAt: 'desc' }, take: 8 });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Certificate Dashboard</h1>
        <p className="text-slate-600">Manage Let’s Encrypt and ACME certificates with Azure DNS DNS-01 automation.</p>
      </div>
      <div className="grid gap-4 md:grid-cols-4">
        <Metric label="Total" value={total} />
        <Metric label="Issued" value={issued} />
        <Metric label="Failed" value={failed} />
        <Metric label="Expiring ≤30 days" value={expiring} />
      </div>
      <section className="card p-5">
        <h2 className="mb-4 text-xl font-semibold">Recent certificates</h2>
        <div className="space-y-3">
          {recent.map(c => (
            <div key={c.id} className="flex items-center justify-between rounded-xl border p-3">
              <div>
                <div className="font-medium">{c.commonName}</div>
                <div className="text-sm text-slate-500">{c.status} · expires {c.notAfter?.toISOString().slice(0,10) ?? 'pending'}</div>
              </div>
              <a className="btn-secondary" href={`/certificates/${c.id}`}>Open</a>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: number }) {
  return <div className="card p-5"><div className="text-sm text-slate-500">{label}</div><div className="mt-2 text-3xl font-bold">{value}</div></div>;
}
