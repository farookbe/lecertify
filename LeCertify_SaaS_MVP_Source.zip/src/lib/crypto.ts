import crypto from 'crypto';

function getKey() {
  const raw = process.env.CERT_ENCRYPTION_KEY_BASE64;
  if (!raw) throw new Error('CERT_ENCRYPTION_KEY_BASE64 is required');
  const key = Buffer.from(raw, 'base64');
  if (key.length !== 32) throw new Error('CERT_ENCRYPTION_KEY_BASE64 must decode to 32 bytes');
  return key;
}

export function encryptText(plain: string) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', getKey(), iv);
  const encrypted = Buffer.concat([cipher.update(plain, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return Buffer.concat([iv, tag, encrypted]).toString('base64');
}

export function decryptText(payload: string) {
  const data = Buffer.from(payload, 'base64');
  const iv = data.subarray(0, 12);
  const tag = data.subarray(12, 28);
  const encrypted = data.subarray(28);
  const decipher = crypto.createDecipheriv('aes-256-gcm', getKey(), iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(encrypted), decipher.final()]).toString('utf8');
}
