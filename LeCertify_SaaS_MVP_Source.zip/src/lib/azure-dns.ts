import { ClientSecretCredential } from '@azure/identity';
import { DnsManagementClient } from '@azure/arm-dns';

function client() {
  const credential = new ClientSecretCredential(
    process.env.AZURE_TENANT_ID!,
    process.env.AZURE_CLIENT_ID!,
    process.env.AZURE_CLIENT_SECRET!
  );
  return new DnsManagementClient(credential, process.env.AZURE_SUBSCRIPTION_ID!);
}

function relativeName(fqdn: string, zone: string) {
  const f = fqdn.replace(/\.$/, '');
  const z = zone.replace(/\.$/, '');
  if (f === z) return '@';
  return f.endsWith('.' + z) ? f.slice(0, -(z.length + 1)) : f;
}

export function cnameTargetForDomain(domain: string) {
  const clean = domain.replace(/^\*\./, '').replace(/\./g, '-');
  return `${clean}.${process.env.AZURE_VALIDATION_DNS_ZONE}`;
}

export async function upsertValidationTxt(domain: string, value: string) {
  const dns = client();
  const validationZone = process.env.AZURE_VALIDATION_DNS_ZONE!;
  const target = cnameTargetForDomain(domain);
  const name = relativeName(target, validationZone);
  await dns.recordSets.createOrUpdate(
    process.env.AZURE_VALIDATION_DNS_RESOURCE_GROUP!,
    validationZone,
    name,
    'TXT',
    {
      ttl: Number(process.env.AZURE_DNS_TTL ?? '60'),
      txtRecords: [{ value: [value] }]
    }
  );
  return { zone: validationZone, name, fqdn: target };
}

export async function deleteValidationTxt(domain: string) {
  const dns = client();
  const validationZone = process.env.AZURE_VALIDATION_DNS_ZONE!;
  const target = cnameTargetForDomain(domain);
  const name = relativeName(target, validationZone);
  await dns.recordSets.deleteMethod(
    process.env.AZURE_VALIDATION_DNS_RESOURCE_GROUP!,
    validationZone,
    name,
    'TXT'
  ).catch(() => undefined);
}

export async function upsertChallengeCname(domain: string) {
  const dns = client();
  const primaryZone = process.env.AZURE_PRIMARY_DNS_ZONE!;
  const challenge = `_acme-challenge.${domain.replace(/^\*\./, '')}`;
  const target = cnameTargetForDomain(domain);
  const name = relativeName(challenge, primaryZone);
  await dns.recordSets.createOrUpdate(
    process.env.AZURE_PRIMARY_DNS_RESOURCE_GROUP!,
    primaryZone,
    name,
    'CNAME',
    {
      ttl: Number(process.env.AZURE_DNS_TTL ?? '60'),
      cnameRecord: { cname: target }
    }
  );
  return { zone: primaryZone, name, target };
}
