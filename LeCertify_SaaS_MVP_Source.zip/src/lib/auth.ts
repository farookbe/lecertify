import type { NextAuthOptions } from 'next-auth';
import AzureADProvider from 'next-auth/providers/azure-ad';

export const authOptions: NextAuthOptions = {
  providers: process.env.ENTRA_ID_ENABLED === 'true' ? [
    AzureADProvider({
      tenantId: process.env.ENTRA_ID_TENANT_ID!,
      clientId: process.env.ENTRA_ID_CLIENT_ID!,
      clientSecret: process.env.ENTRA_ID_CLIENT_SECRET!
    })
  ] : [],
  callbacks: {
    async session({ session }) {
      return session;
    }
  }
};
