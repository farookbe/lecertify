import acme from 'acme-client';
import { encryptText } from './crypto';
import { deleteValidationTxt, upsertChallengeCname, upsertValidationTxt } from './azure-dns';

type IssueInput = {
  commonName: string;
  subjectAltNames: string[];
  caDirectoryUrl: string;
  useCnameDelegation: boolean;
};

const wait = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export async function issueCertificate(input: IssueInput) {
  const accountKey = await acme.crypto.createPrivateKey();
  const client = new acme.Client({
    directoryUrl: input.caDirectoryUrl,
    accountKey
  });

  await client.createAccount({
    termsOfServiceAgreed: true,
    contact: [`mailto:${process.env.ACME_ACCOUNT_EMAIL}`]
  });

  const domains = Array.from(new Set([input.commonName, ...input.subjectAltNames].filter(Boolean)));
  const [key, csr] = await acme.crypto.createCsr({ commonName: input.commonName, altNames: domains });

  const cert = await client.auto({
    csr,
    email: process.env.ACME_ACCOUNT_EMAIL,
    termsOfServiceAgreed: true,
    challengePriority: ['dns-01'],
    challengeCreateFn: async (_authz, challenge, keyAuthorization) => {
      const domain = challenge.identifier?.value ?? input.commonName;
      const dnsValue = await acme.crypto.createHash(keyAuthorization);
      if (input.useCnameDelegation && process.env.AZURE_AUTO_CREATE_CNAME === 'true') {
        await upsertChallengeCname(domain);
      }
      await upsertValidationTxt(domain, dnsValue);
      await wait(Number(process.env.ACME_DNS_PROPAGATION_SECONDS ?? '120') * 1000);
    },
    challengeRemoveFn: async (_authz, challenge) => {
      if (process.env.ACME_CLEANUP_DNS !== 'true') return;
      const domain = challenge.identifier?.value ?? input.commonName;
      await deleteValidationTxt(domain);
    }
  });

  return {
    certPem: cert.toString(),
    privateKeyPem: key.toString(),
    encryptedCertPem: encryptText(cert.toString()),
    encryptedPrivateKey: encryptText(key.toString())
  };
}
