# LeCertify Architecture

## MVP

- Next.js app router for UI and API routes
- PostgreSQL via Prisma
- NextAuth with Entra ID provider
- acme-client for ACME DNS-01 issuance
- Azure SDK for DNS TXT/CNAME automation
- AES-256-GCM encrypted certificate/private key fields

## Production hardening roadmap

1. Move issuance from serverless API route to durable background worker.
2. Add Azure Key Vault storage backend.
3. Add RBAC enforcement middleware.
4. Add API keys for certificate consumers.
5. Add Teams/email notification provider.
6. Add certificate download endpoints with audited access.
7. Add deploy hooks for IIS, NetScaler, Nginx and Azure App Service.
